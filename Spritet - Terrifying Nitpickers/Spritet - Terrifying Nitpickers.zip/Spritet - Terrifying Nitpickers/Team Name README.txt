Terrifying Nitpickers
Jet Vellinga
Guy Wattson
Ross DiMassimo
Simon Redman
Yiliang Shi
Qixiang Chao

Submitted on u0928726 repository

The program expects a properly installed ImageMagic setup. Test by running Magick++-config --cppflags. This works on the Lab2 machines.